-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 02-Dez-2022 às 02:17
-- Versão do servidor: 10.5.18-MariaDB-1:10.5.18+maria~ubu2004
-- versão do PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `new_ads`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_customers`
--

CREATE TABLE `tb_customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `cpf` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `cnpj` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `cellphone` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `birthdate` datetime DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `admin_id` bigint(20) NOT NULL DEFAULT 2,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_domains`
--

CREATE TABLE `tb_domains` (
  `id` bigint(20) NOT NULL,
  `customer_id` bigint(20) NOT NULL DEFAULT 0,
  `domain` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `admin_id` bigint(20) NOT NULL DEFAULT 2,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tb_domains`
--

INSERT INTO `tb_domains` (`id`, `customer_id`, `domain`, `status`, `admin_id`, `created_at`, `updated_at`) VALUES
(1, 0, 'https://lavorofinanza.com', 1, 2, '2022-10-05 13:57:49', '2022-10-20 19:52:24'),
(2, 0, 'https://financasevagas.com', 1, 2, '2022-10-05 16:57:22', '2022-10-24 15:17:44'),
(5, 0, 'https://it.opportunitiesjobs.com', 1, 2, '2022-10-20 19:53:24', '2022-10-20 22:53:24'),
(6, 0, 'https://es.financasevagas.com', 1, 2, '2022-10-20 19:53:39', '2022-10-20 19:55:58'),
(7, 0, 'https://es.opportunitiesjobs.com', 1, 2, '2022-10-20 19:54:09', '2022-10-20 22:54:09'),
(9, 0, 'https://linktr.ee/carlosramosweb', 1, 5, '2022-10-25 14:28:43', '2022-10-25 17:25:55'),
(11, 0, 'https://criacaocriativa.com', 1, 1, '2022-10-26 15:31:37', '2022-10-26 18:31:37');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_expenses`
--

CREATE TABLE `tb_expenses` (
  `id` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date_at` datetime NOT NULL,
  `expense` decimal(50,2) NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `admin_id` bigint(20) NOT NULL DEFAULT 2,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_goals`
--

CREATE TABLE `tb_goals` (
  `id` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date_at` date NOT NULL,
  `goals` decimal(50,2) NOT NULL,
  `customer_id` bigint(20) DEFAULT NULL,
  `admin_id` bigint(20) NOT NULL DEFAULT 2,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tb_goals`
--

INSERT INTO `tb_goals` (`id`, `title`, `date_at`, `goals`, `customer_id`, `admin_id`, `created_at`, `updated_at`) VALUES
(10, 'Metas', '2022-10-01', '30000.00', 0, 2, '2022-10-25 14:54:43', '2022-11-04 14:54:07'),
(11, 'Metas', '2022-09-01', '30000.00', 0, 2, '2022-10-25 14:55:27', '2022-10-25 17:55:27'),
(12, 'Metas', '2022-10-01', '5000.00', 0, 5, '2022-10-25 15:31:00', '2022-10-25 18:31:00'),
(13, 'Metas', '2022-09-01', '15000.00', 0, 5, '2022-10-25 17:57:31', '2022-10-25 20:57:31'),
(14, 'Metas', '2022-08-01', '30000.00', 0, 2, '2022-10-25 23:00:48', '2022-10-26 02:00:48'),
(16, 'Metas', '2022-11-01', '30000.00', 0, 2, '2022-11-04 14:54:39', '2022-11-19 12:30:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_invalids`
--

CREATE TABLE `tb_invalids` (
  `id` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date_at` date NOT NULL,
  `invalid` decimal(50,2) NOT NULL,
  `customer_id` bigint(20) DEFAULT NULL,
  `admin_id` bigint(20) NOT NULL DEFAULT 2,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_payments`
--

CREATE TABLE `tb_payments` (
  `id` bigint(20) NOT NULL,
  `date_at` date NOT NULL,
  `total_revenue` decimal(50,2) NOT NULL,
  `invalids` decimal(50,2) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 1,
  `rate` decimal(50,2) NOT NULL,
  `net_revenue` decimal(50,2) DEFAULT NULL,
  `quotation` decimal(50,2) NOT NULL,
  `expense` decimal(50,2) NOT NULL,
  `exchange_rate` decimal(50,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `total_receivable` decimal(50,2) DEFAULT NULL,
  `admin_id` bigint(20) NOT NULL DEFAULT 2,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_revenues`
--

CREATE TABLE `tb_revenues` (
  `id` bigint(20) NOT NULL,
  `date_at` date NOT NULL,
  `author_id` bigint(20) NOT NULL,
  `domain` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `currency` tinyint(1) NOT NULL DEFAULT 1,
  `revenue` decimal(50,2) NOT NULL,
  `views` int(11) NOT NULL,
  `printing` int(20) NOT NULL,
  `reading_at` varchar(255) NOT NULL,
  `admin_id` bigint(20) NOT NULL DEFAULT 2,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Estrutura da tabela `tb_users`
--

CREATE TABLE `tb_users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `role` int(2) NOT NULL DEFAULT 2,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_id` tinyint(1) NOT NULL DEFAULT 2,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Extraindo dados da tabela `tb_users`
--

INSERT INTO `tb_users` (`id`, `name`, `email`, `password`, `photo`, `phone`, `role`, `last_activity`, `admin_id`, `created_at`, `updated_at`) VALUES
(1, 'Desenvolvedor', 'developer@exemplo.com', '20b6d74e1cf5e6467f272b8742d430fd', '', '', 1, '2022-12-01 23:16:46', 1, '2022-07-04 13:16:00', '2022-10-26 14:37:58'),

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_customers`
--
ALTER TABLE `tb_customers`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tb_domains`
--
ALTER TABLE `tb_domains`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tb_expenses`
--
ALTER TABLE `tb_expenses`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tb_goals`
--
ALTER TABLE `tb_goals`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tb_invalids`
--
ALTER TABLE `tb_invalids`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tb_payments`
--
ALTER TABLE `tb_payments`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tb_revenues`
--
ALTER TABLE `tb_revenues`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_customers`
--
ALTER TABLE `tb_customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tb_domains`
--
ALTER TABLE `tb_domains`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `tb_expenses`
--
ALTER TABLE `tb_expenses`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT de tabela `tb_goals`
--
ALTER TABLE `tb_goals`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `tb_invalids`
--
ALTER TABLE `tb_invalids`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `tb_payments`
--
ALTER TABLE `tb_payments`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `tb_revenues`
--
ALTER TABLE `tb_revenues`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=309;

--
-- AUTO_INCREMENT de tabela `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
